class Estoque
{
    int id;
    int producaoId;
    decimal quantidade;
    string local;
}