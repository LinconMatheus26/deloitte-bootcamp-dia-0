public class Minerio
{
    public string codigo;
    public string tipo;
}