namespace ValeMonitoramento.Models.enums;

public enum StatusOperacional 
{ 
    Operacional, 
    EmManutencao, 
    Parado 
}