namespace ValeMonitoramento.Models.Enums;

public enum TipoEquipamento 
{ 
    Caminhao, 
    Escavadeira, 
    Perfuratriz, 
    Carregadeira, 
    Trator 
}